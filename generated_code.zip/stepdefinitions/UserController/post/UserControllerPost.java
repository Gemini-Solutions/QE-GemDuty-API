package stepdefinitions.UserController.post;

import io.cucumber.java.en.*;
import net.serenitybdd.rest.SerenityRest;
import org.json.JSONObject;
import static org.junit.Assert.*;

public class UserControllerPost {

    private String baseUrl;

    @Given("the base URL is {string}")
    public void setBaseUrl(String url) {
        this.baseUrl = url;
    }

    @When("I send a POST request to {string} with body:")
    public void sendPostRequest(String endpoint, String body) {
        SerenityRest.given()
            .baseUri(baseUrl)
            .contentType("application/json")
            .body(body)
            .when()
            .post(endpoint);
    }

    @When("I send a POST request to {string}")
    public void sendPostRequestWithoutBody(String endpoint) {
        SerenityRest.given()
            .baseUri(baseUrl)
            .when()
            .post(endpoint);
    }

    @Then("the response status code should be {int}")
    public void verifyResponseStatusCode(int expectedStatusCode) {
        assertEquals(expectedStatusCode, SerenityRest.lastResponse().getStatusCode());
    }

    @And("the response body should contain a string")
    public void verifyResponseBodyContainsString() {
        String responseBody = SerenityRest.lastResponse().getBody().asString();
        assertNotNull(responseBody);
        assertFalse(responseBody.isEmpty());
    }

    @And("the response body should contain an error message")
    public void verifyResponseBodyContainsErrorMessage() {
        String responseBody = SerenityRest.lastResponse().getBody().asString();
        JSONObject jsonResponse = new JSONObject(responseBody);
        assertTrue(jsonResponse.has("message"));
        assertFalse(jsonResponse.getString("message").isEmpty());
    }
}