import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.Map;

public class CreateUserStepDefs {
    private RequestSpecification request;
    private Response response;

    @Given("the base URL is {string}")
    public void set_base_url(String hostUrl) {
        RestAssured.baseURI = hostUrl;
    }

    @Given("the {string} header is {string}")
    public void set_header(String headerName, String headerValue) {
        request = RestAssured.given().header(headerName, headerValue);
    }

    @When("I send a {string} request to {string} with the following:")
    public void send_request(String method, String endpoint, Map<String, String> requestBody) {
        request.body(requestBody);
        response = request.request(method, endpoint);
    }

    @Then("the response status code should be {int}")
    public void verify_status_code(int expectedStatusCode) {
        response.then().assertThat(response -> response.statusCode(expectedStatusCode));
    }
}