import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ListUsersStepDefs {
    private RequestSpecification request;
    private Response response;

    @Given("the base URL is {string}")
    public void set_base_url(String hostUrl) {
        RestAssured.baseURI = hostUrl;
    }

    @Given("the {string} header is {string}")
    public void set_header(String headerName, String headerValue) {
        request = RestAssured.given().header(headerName, headerValue);
    }

    @When("I send a GET request to {string}")
    public void send_get_request(String path) {
        response = request.get(path);
    }

    @Then("the response status code should be {int}")
    public void verify_status_code(int expectedStatusCode) {
        response.then().assertThat(response -> response.statusCode(expectedStatusCode));
    }

    @Then("the response body should be a JSON array")
    public void verify_response_body() {
        response.then().assertThat(response -> response.body("$.size()", Matchers.greaterThanOrEqualTo(0)));
    }
}