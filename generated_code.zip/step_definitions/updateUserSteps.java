import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.Map;

public class UpdateUserSteps {
    private RequestSpecification request;
    private Response response;

    @Given("the base URL is {string}")
    public void set_base_url(String hostUrl) {
        RestAssured.baseURI = hostUrl;
    }

    @Given("the authorization token is {string}")
    public void set_auth_token(String authToken) {
        request = RestAssured.given().header("Authorization", "Bearer " + authToken);
    }

    @When("I send a PATCH request to {string} with the following data:")
    public void send_patch_request(String url, Map<String, String> data) {
        request.body(data);
        response = request.patch(url);
    }

    @Then("the response status code should be {int}")
    public void verify_status_code(int statusCode) {
        response.then().assertThat(response -> response.statusCode(statusCode));
    }

    @Then("the response body should contain {string}")
    public void verify_response_body(String expectedValue) {
        response.then().assertThat(response -> response.body(expectedValue));
    }
}